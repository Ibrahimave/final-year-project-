from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import base64
import io
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow import keras

# Import preprocessing utilities
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), 'utils'))
from preprocessing import preprocess_image

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configuration
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'oral_cancer_model.h5')
CLASS_NAMES = ['Cancerous', 'Normal', 'PreCancerous']  # Alphabetical order (default for Keras)

# Global variable to store loaded model
model = None


def load_model():
    """Load the trained model"""
    global model
    
    if model is None:
        if not os.path.exists(MODEL_PATH):
            print(f"ERROR: Model not found at {MODEL_PATH}")
            print("\nTo create a placeholder model for testing, run:")
            print("  python backend/utils/model_builder.py")
            print("\nTo train a real model:")
            print("  1. Download the Kaggle oral cancer dataset")
            print("  2. Run: python backend/utils/prepare_dataset.py")
            print("  3. Run: python backend/utils/train_model.py")
            return None
        
        try:
            print(f"Loading model from {MODEL_PATH}...")
            model = keras.models.load_model(MODEL_PATH)
            print("Model loaded successfully!")
            print(f"Model input shape: {model.input_shape}")
            print(f"Model output shape: {model.output_shape}")
        except Exception as e:
            print(f"Error loading model: {e}")
            return None
    
    return model


def get_recommendation(predicted_class, confidence):
    """
    Get medical recommendation based on prediction
    
    Args:
        predicted_class: Predicted class name
        confidence: Confidence percentage
    
    Returns:
        Recommendation string
    """
    if predicted_class == 'Normal':
        if confidence >= 90:
            return "Safe - Continue regular oral hygiene practices"
        else:
            return "Likely Safe - Monitor regularly and maintain good oral hygiene"
    
    elif predicted_class == 'PreCancerous':
        if confidence >= 80:
            return "Monitor Regularly - Consult a specialist for evaluation"
        else:
            return "Uncertain - Recommend professional medical examination"
    
    elif predicted_class == 'Cancerous':
        if confidence >= 70:
            return "Consult Specialist Immediately - Further diagnostic tests required"
        else:
            return "Potential Concern - Urgent medical consultation recommended"
    
    return "Consult a medical professional for proper diagnosis"


def get_warning_message(predicted_class):
    """
    Get warning message based on prediction
    
    Args:
        predicted_class: Predicted class name
    
    Returns:
        Warning message string
    """
    if predicted_class == 'Normal':
        return "No immediate concerns detected. Continue regular dental check-ups."
    
    elif predicted_class == 'PreCancerous':
        return "Pre-cancerous condition detected. Early intervention can prevent progression to cancer."
    
    elif predicted_class == 'Cancerous':
        return "Cancerous condition detected. Immediate medical attention is strongly recommended."
    
    return "Please consult a healthcare professional for accurate diagnosis."


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    model_status = "loaded" if model is not None else "not loaded"
    return jsonify({
        'status': 'healthy',
        'model_status': model_status,
        'model_path': MODEL_PATH
    })


@app.route('/predict', methods=['POST'])
def predict():
    """
    Prediction endpoint
    
    Accepts:
        - Multipart form data with 'image' file
        - JSON with 'image' as base64 string
    
    Returns:
        JSON with prediction results
    """
    try:
        # Load model if not already loaded
        current_model = load_model()
        if current_model is None:
            return jsonify({
                'error': 'Model not loaded',
                'message': 'Please create or train the model first. See console for instructions.'
            }), 500
        
        # Get image from request
        image_data = None
        
        # Check for multipart form data
        if 'image' in request.files:
            file = request.files['image']
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            # Read image data
            image_data = file.read()
        
        # Check for JSON with base64 image
        elif request.is_json:
            data = request.get_json()
            if 'image' not in data:
                return jsonify({'error': 'No image data provided'}), 400
            
            # Decode base64 image
            try:
                # Remove data URL prefix if present
                base64_str = data['image']
                if ',' in base64_str:
                    base64_str = base64_str.split(',')[1]
                
                image_data = base64.b64decode(base64_str)
            except Exception as e:
                return jsonify({'error': f'Invalid base64 image: {str(e)}'}), 400
        
        else:
            return jsonify({'error': 'No image provided'}), 400
        
        # Preprocess image
        try:
            preprocessed_image = preprocess_image(image_data)
        except Exception as e:
            return jsonify({'error': f'Image preprocessing failed: {str(e)}'}), 400
        
        # Make prediction
        try:
            predictions = current_model.predict(preprocessed_image, verbose=0)
            predicted_probabilities = predictions[0]
            predicted_class_idx = np.argmax(predicted_probabilities)
            predicted_class = CLASS_NAMES[predicted_class_idx]
            confidence = float(predicted_probabilities[predicted_class_idx] * 100)
            
            # Create probability dictionary
            probabilities = {
                class_name: float(prob * 100)
                for class_name, prob in zip(CLASS_NAMES, predicted_probabilities)
            }
            
            # Get recommendation and warning
            recommendation = get_recommendation(predicted_class, confidence)
            warning = get_warning_message(predicted_class)
            
            # Prepare response
            response = {
                'prediction': predicted_class,
                'confidence': round(confidence, 2),
                'probabilities': {k: round(v, 2) for k, v in probabilities.items()},
                'recommendation': recommendation,
                'warning': warning,
                'disclaimer': 'This is an AI-assisted tool for educational purposes only. Always consult qualified medical professionals for accurate diagnosis and treatment.'
            }
            
            print(f"\nPrediction made: {predicted_class} ({confidence:.2f}%)")
            
            return jsonify(response), 200
        
        except Exception as e:
            return jsonify({'error': f'Prediction failed: {str(e)}'}), 500
    
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500


@app.route('/', methods=['GET'])
def index():
    """Root endpoint"""
    return jsonify({
        'message': 'Oral Cancer Classification API',
        'version': '1.0.0',
        'endpoints': {
            'health': '/health',
            'predict': '/predict (POST)'
        }
    })


if __name__ == '__main__':
    print("="*60)
    print("ORAL CANCER CLASSIFICATION API")
    print("="*60)
    print(f"Model path: {MODEL_PATH}")
    
    # Try to load model on startup
    load_model()
    
    print("\nStarting Flask server...")
    print("API will be available at: http://localhost:5000")
    print("="*60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
